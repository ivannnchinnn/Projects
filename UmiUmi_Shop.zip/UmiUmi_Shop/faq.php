<?php

@include 'db.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};


if(isset($_POST['add_to_cart'])){

   $pid = $_POST['pid'];
   $pid = filter_var($pid, FILTER_SANITIZE_STRING);
   $p_name = $_POST['p_name'];
   $p_name = filter_var($p_name, FILTER_SANITIZE_STRING);
   $p_price = $_POST['p_price'];
   $p_price = filter_var($p_price, FILTER_SANITIZE_STRING);
   $p_image = $_POST['p_image'];
   $p_image = filter_var($p_image, FILTER_SANITIZE_STRING);
   $p_qty = $_POST['p_qty'];
   $p_qty = filter_var($p_qty, FILTER_SANITIZE_STRING);

   $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE name = ? AND user_id = ?");
   $check_cart_numbers->execute([$p_name, $user_id]);

   if($check_cart_numbers->rowCount() > 0){
      $message[] = 'already added to cart!';
   }else{
      $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
      $insert_cart->execute([$user_id, $pid, $p_name, $p_price, $p_qty, $p_image]);
      $message[] = 'added to cart!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Frequently Asked Questions</title>
    <link rel="stylesheet" href="faq.css" />
    <link rel="stylesheet" href="css/style.css">

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <style>
      .wrapper .faq .pannel{
        font-size 30px;
      }
    </style>
  </head>
  <body>
<?php include 'header.php'; ?>

    <div class="wrapper">
      <img src="Screenshot 2024-10-08 020354.png" alt="">
      <h1>Frequently Asked Questions</h1>

      <div class="faq">
        <button class="accordion">
          <h2>How to cancel an order?</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2> You want to change or cancel an order after you had checkout it completely?</h2>
              <br>

              The suggestion below given to change or cancel an order following
              <br>
              Login to your account and cancel the order from the purchase list.
              If you did not have an account, please register a new account to cancel your order.
              If u cannot cancel your order from the purchase list, please contact our customer support to get help.
              If you want to cancel your order, please make it within 24hours before the order delivered.
          </p>
        </div>
      </div>

      <div class="faq">
        <button class="accordion">
          <h2>Track Return</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2>Tracking your returns depends on your return method. Kindly keep note of the return tracking number which can be found either on the return label or
                on your receipt which you shoold receive / request upon parcel drop-off. You will be notified once your parcel has been received and processed by shop.</h2>
                
                <br>
                <br>
                <h5>PostCo</h5>
                The tracking number is a series of 11 numerical digits which can be found in the e-mail sent to you from PostCo, fter you book your return.
                
                Simply key in your tracking number at PostCo's e-tracker to track your return parcel.
                
                <br>
                <br>
                <h5>PosLaju</h5>
                The tracking number is a series of 13 alphanumeric digits which can be found at the top right corner of your return label/proof of drop-off.
                
                Simply head over to the PosLaju e-tracker to track the whereabouts of your return parcel.
                
                <br>
                <br>
                <h5>CollectCo</h5>
                The tracking number is made up of 12 numerical digits which can be found either on your return label/proof of drop-off. Simply input this number at CollectCo's e-tracker to track your return parcel.
                
                Please note if the drop-off centres are unable to provide a physical receipt
                
                you may request for "proof of drop-off" via email instead.
                
                Your tracking number shoold go live within 30 minutes of drop off, otherwise you may reach out to CollectCo here.
                
                <br>
                <br>
                <h5>Ninjavan</h5>
                The tracking number is made up of 10 numerical digits which can be found either on your return label/proof of drop-off.
                
                Simply type this number at Ninjavan's e-tracker to track your return parcel.
          </p>
        </div>
      </div>

      <div class="faq">
        <button class="accordion">
          <h2>How to make payment?</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2>Confusing of making payment after choosen your order?</h2>       
            <br>
            <br>
            Below show the ways of how to make the payment
            <br>
            <br>
            1.Click on the Purchase button<br>
            2.Choose the payment method<br>
            3.Choose the type of card<br>
            4.Select the type of bank<br>
            5.Enter the account<br>
            6.After done the ways above,click Submit<br>
            7.After you had done your payment, advice to save your receipt of payment to prevent any mistakes.
            <br>
          </p>
        </div>
      </div>

      <div class="faq">
        <button class="accordion">
          <h2>About the delivery</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2>Confusing of delivery?</h2>
            <br>
            Once you have done your order and payment, we will arange the delivery within 2days.<br>
            The delivery will follow the address fill up to sent to you.<br>
            FREE Delivery is provided on all the orders of $99 and above. Any details about delivery fee can checkout in payment page.<br>
            If you received an incomplete package, please take a picture of the package and send or contact wiyou th our customer support as a proven.<br>
            If you want to order, please make sure you are not in the overseas country. We are sorry about that we are not provide delivery to overseas.
            <br>
          </p>
        </div>
      </div>

      <div class="faq">
        <button class="accordion">
          <h2>How to create an account</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2>Don't have an account yet? Follow these simple steps and you can start shopping with your account!</h2><br>

            Here’s how to get started with us:<br>
            <br>

            Mobile App<br>
            Step 1: Go to the "Account" button on the bottom right corner of your screen.
            Step 2: Click on the "Login" button at the top of your screen.
            Step 3: Select "Register" and choose to register either via Facebook or by manually filling in all of the details. Click "Create Account" and rest assured, all your details will be kept private.
            This completes your registration. You will receive an email confirmation along with a cash voucher (if you opted to subscribe to RIZEN) to get you started!
            <br>
            <br>
            Desktop<br>
            Step One: Go to "My Account" on the top right hand bar and select "Register".
            Step Two: You can choose to register either via Facebook or by manually filling in all of the details. Click "Submit" and rest assured, all your details will be kept private.
          </p>
        </div>
      </div>

      <div class="faq">
        <button class="accordion">
          <h2>Size Guide</h2>
          <i class="fa-solid fa-chevron-down"></i>
        </button>
        <div class="pannel">
          <p>
            <br>
            <h2>How to MEASURE the product's size</h2>
            <br>
            1.Length<br>
            Measure from the front waistband to the leg opening.<br>
            <br>
            2.Waist<br>
            Measure the circumference straight across the top of the waistband.<br>
            <br>
            3.Hip<br>
            Measure the circumference at 15CM vertically under the top of the waistband.<br>
            <br>

            *This data was obtained from manually measuring the product.it may be off by 1-2CM

.
          </p>
        </div>
      </div>
    </div>
    

    <script>
      var acc = document.getElementsByClassName("accordion");
      var i;

      for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function () {
          this.classList.toggle("active");
          this.parentElement.classList.toggle("active");

          var pannel = this.nextElementSibling;

          if (pannel.style.display === "block") {
            pannel.style.display = "none";
          } else {
            pannel.style.display = "block";
          }
        });
      }
    </script>
  </body>


</html>
