-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2024 at 02:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pid`, `name`, `price`, `quantity`, `image`) VALUES
(66, 35, 27, 'Desert Mirage Polo', 29, 1, 'clothes1.1.png'),
(67, 31, 27, 'Desert Mirage Polo', 29, 1, 'clothes1.1.png');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(16, 31, '123435', '12435', 'i@i.com', 'E-Wallet', 'flat no. 12435 12435 1245 1245 1245 - 12435', ', Midnight Eclipse Tote ( 1 ), Desert Mirage Polo ( 1 )', 40, '17-Oct-2024', 'completed'),
(17, 35, 'fgh', '12345', 'ivanchin3618@gmail.com', 'E-Wallet', 'flat no. 1243rf edcs x feargfsd 3efdvszd wqefvzcx - 12435', ', Desert Mirage Polo ( 5 ), Azure Sky Gown ( 1 ), Crimson Blaze Henley ( 1 )', 205, '17-Oct-2024', 'pending'),
(18, 35, 'DXFS', '24353', 'sdfhjm@gmail.com', 'E-Wallet', 'flat no. DS DSF DSF DSF DS - 2344', ', Desert Mirage Polo ( 1 ), Crimson Blaze Henley ( 1 )', 78, '17-Oct-2024', 'pending'),
(19, 35, 'ESTER', '01111090', 'ester@gmail.com', 'Cash-On Delivery', 'flat no. pandan jaga pajinpashan ampang kuala lumpur malaysia - 58000', ', Twilight V-Neck Tee ( 1 ), Desert Mirage Polo ( 1 )', 68, '17-Oct-2024', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `details`, `price`, `image`) VALUES
(26, 'Twilight V-Neck Tee', 'Men', 'A deep navy V-neck T-shirt with a smooth, lightweight fabric that feels like a cool evening breeze. Perfect for casual evenings or adding a touch of elegance to your laid-back look.', 39, 'clothes1.png'),
(27, 'Desert Mirage Polo', 'Men', 'A short-sleeved, sand-colored polo with subtle ombré shading that mirrors the vast horizons of a desert landscape. Its breathable cotton fabric keeps you cool in the hottest of climates.', 29, 'clothes1.1.png'),
(28, 'Crimson Blaze Henley', 'Men', 'A vibrant black short-sleeve Henley with fire-like accents along the buttons. Bold and eye-catching, this top brings the heat wherever you go, ideal for making a statement.', 49, 'clothes2.1.png'),
(29, 'Petal Whisper Dress', 'Women', 'A soft pink dress adorned with delicate floral appliqués that bloom across the bodice and skirt. The flowing chiffon material makes it feel like you&#39;re wearing a bouquet of roses.', 40, 'dress3.png'),
(30, 'Sunshine Twirl Dress', 'Women', 'A bright yellow A-line dress with a flared skirt, perfect for twirling under the summer sun. The playful ruffles and subtle polka dots give it a joyful, carefree vibe.', 79, 'dress4.png'),
(31, 'Mint Meadow Dress', 'Women', 'A soft, mint-green dress with delicate floral embroidery along the neckline and hem. The breezy, lightweight fabric gives it a fresh and airy look, perfect for spring picnics or sunny days in the park.', 79, 'dress5.png'),
(32, 'Emerald Enchantment Gown', 'Women', 'A deep emerald-green gown with a velvet bodice and a flowing satin skirt. The rich, luxurious color adds a touch of elegance and sophistication, making it ideal for formal events or holiday celebrations.', 11, 'dress1.png'),
(33, 'Midnight Eclipse Tote', 'Accessories', 'A sleek black leather tote with a minimalist design and gold hardware. This spacious bag is perfect for carrying all your essentials while exuding a sense of timeless sophistication. The structured silhouette makes it a versatile piece for both day and night.', 11, 'accessories3.png'),
(34, 'Blush Bloom Satchel', 'Accessories', 'A soft, blush-pink satchel with delicate floral embroidery along the edges. The structured design, paired with its pastel hue, makes it both elegant and playful, ideal for adding a touch of femininity to any outfit.', 11, 'accessories4.1.png'),
(35, 'Ivory Whisper Clutch', 'Accessories', 'A crisp white clutch with subtle pearl detailing and a smooth satin finish. Perfect for formal occasions or summer events, this small yet chic accessory adds a dash of elegance to your ensemble.', 11, 'accessories5.png'),
(36, 'Snowdrift Heels', 'Accessories', 'Elegant white satin heels with a pointed toe and delicate ankle straps. These classic shoes feature a subtle shimmer, perfect for weddings or formal events, giving you an ethereal, graceful appearance.', 11, 'accessories1.png'),
(37, 'Pearl Glimmer Flats', 'Accessories', 'Graceful white ballet flats with a satin finish, embellished with tiny pearl accents across the toe. These comfortable yet elegant flats are perfect for adding a touch of sophistication to both casual and formal outfits, ensuring you glide through the day with ease and style.', 11, 'accessories2.png'),
(38, 'Azure Sky Gown', 'rec', 'A breathtaking floor-length gown in a soft, flowing fabric that mirrors the serenity of a clear blue sky. The bodice is adorned with delicate silver embroidery, resembling twinkling stars, while the lightweight chiffon skirt glides gracefully with every movement. Ideal for evening events, this dress captures the beauty and tranquility of the heavens, making you the embodiment of elegance.', 11, 'dress2.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`, `image`) VALUES
(31, 'Ivan chin', 'ivanchin@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', 'user', 'logo.png.png'),
(32, 'admin', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', 'admin', 'logo.png.png'),
(33, 'Ivan0909', 'ivanchin0909@gmail.com', '202cb962ac59075b964b07152d234b70', 'admin', 'lichi.png'),
(35, 'ivanchin', 'ivan@gmail.com', '202cb962ac59075b964b07152d234b70', 'user', 'accessories2.1.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
