let navbar = document.querySelector('.header .flex .navbar');

document.querySelector('#menu-btn').onclick = () =>{
   navbar.classList.toggle('active');
   profile.classList.remove('active');//缩小到一定程度 变成menu button
}

let profile = document.querySelector('.header .flex .profile');

document.querySelector('#user-btn').onclick = () =>{
   profile.classList.toggle('active');
   navbar.classList.remove('active');
}

window.onscroll = () =>{
   profile.classList.remove('active');
   navbar.classList.remove('active');
}
function addToCart(name, price) {
   const existingItem = cart.find(item => item.name === name);
   if (existingItem) {
       existingItem.quantity += 1;
   } else {
       cart.push({ name, price, quantity: 1 });
   }
   updateCart();
}
