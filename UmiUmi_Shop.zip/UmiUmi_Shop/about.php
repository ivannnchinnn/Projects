<?php

@include 'db.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}
if(isset($_POST['add_to_cart'])){

   $pid = $_POST['pid'];
   $pid = filter_var($pid, FILTER_SANITIZE_STRING);
   $p_name = $_POST['p_name'];
   $p_name = filter_var($p_name, FILTER_SANITIZE_STRING);
   $p_price = $_POST['p_price'];
   $p_price = filter_var($p_price, FILTER_SANITIZE_STRING);
   $p_image = $_POST['p_image'];
   $p_image = filter_var($p_image, FILTER_SANITIZE_STRING);
   $p_qty = $_POST['p_qty'];
   $p_qty = filter_var($p_qty, FILTER_SANITIZE_STRING);

   $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE name = ? AND user_id = ?");
   $check_cart_numbers->execute([$p_name, $user_id]);

   if($check_cart_numbers->rowCount() > 0){
      $message[] = 'already added to cart!';
   }else{
      $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
      $insert_cart->execute([$user_id, $pid, $p_name, $p_price, $p_qty, $p_image]);
      $message[] = 'added to cart!';
   }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/styleabout.css">
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

   <section id="wrapper">
      <!--U.mi.U.mi Section-->
      <div class="section1 slidein" id="section1">
         <h2>U.mi.U.mi</h2>
         <h3><a style="text-decoration:none" href="#section2" title="Video">Go to Video Part</a></h3>
         <h3><a style="text-decoration:none" href="#section3" title="Ceo Introduce Part">Go to Ceo Introduce Part</a>
      </h3>
         <!--Picture with zoom functionality-->
         <div class="flex-container2">
               <div class="leftpictureone">
                  <img src="project images/logo.png.png" class="zoomable" width="450" height="350" alt="Logo Image">
               </div>
               <div class="columntext1">
                  <h4>At U.mi.U.mi.</h4>
                  <br>
                  <h4>Fashion Isn’t Just What You Wear</h4>
                  <br>
                  <h4>It's How You Express Yourself</h4>
                  <br>
                  <h4>3F — Fashion, Forward, Forever</h4>
               </div>
         </div>
      </div>

      <!-- Video Section -->
      <div class="section2 slidein" id="section2">
         <div>
            <h2>Spend More Save More</h2>
            <h3><a style="text-decoration:none" href="#section1" title="Company">Go to U.mi.U.mi part</a></h3>
            <h3><a style="text-decoration:none" href="#section3" title="Ceo Introduce">Go to Ceo Introduce Part</a>
         </h3>
         </div>
         <br>
         <!-- Flex container for the text and video -->
         <div class="flex-container">
            <!-- Text column on the left -->
            <div class="columntext2">
               <h4>Fashion for Every You !!!</h4>
               <h4>Start Shopping Today </h4>
               <h4>At UmiUmi.com</h4>
               <h4>Download Our App!</h4>
            </div>
         
            <!-- Video on the right -->
            <div class="right">
            <iframe width="650" height="350" src="https://www.youtube.com/embed/oVX-bdduSQo"
            frameborder="0" allow="accelerometer; autoplay; clipboard-write; envrypted-media; 
            gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
         </div>
      </div>
      
      <!-- CEO Introduce Section -->
      <div class="section3 slidein" id="section3">
         <div>
            <h2>Introduce CEO</h2>
            <h3><a style="text-decoration:none" href="#section1" title="Company">Go to U.mi.U.mi part</a></h3>
            <h3><a style="text-decoration:none" href="#section2" title="Video">Go to Video part</a></h3>
            <br>
            <div class="flex-container2">
               <div class="leftpictureone">
                  <img src="ivan.jpg" class="zoomable" alt="" height="350" width="350">
               </div>
               <div class="columntext3">
               <h4>Ivan Chin Kha Lok</h4>
               <h4>Founder and Former CEO</h4>
               <h4>Founded U.mi.U.mi. in 2024</h4>
               </div>
            </div>
            <br>
            <div class="flex-container2">
               <div class="leftpicturetwo">
                  <img src="ester.jpg" class="zoomable" width="350" height="350" alt="">
               </div>
               <div class="columntext4">
               <h4>Ester Lim Seet Yee</h4>
               <h4>Co-Founder and Head of Design</h4>
               <h4>Latest Trends & Timeless Styles</h4>
               </div>
            </div>
            <br>
            <div class="flex-container2">
               <div class="leftpictureone">
                  <img src="junsheng.jpg" class="zoomable" alt="" height="350" width="350">
               </div>
               <div class="columntext3">
               <h4>Ng Jun Sheng</h4>
               <h4>Head of Fianacial</h4>
               <h4>Managing Financial for U.mi.U.mi</h4>
               </div>
            </div>
            <br>
            <div class="flex-container2">
               <div class="leftpicturetwo">
                  <img src="kelly.jpg" class="zoomable" width="350" height="350" alt="">
               </div>
               <div class="columntext4">
               <h4>Kelli Ooi Khai Li</h4>
               <h4>Head of Human Resource</h4>
               <h4>Managing Human Resources department</h4>
               </div>
            </div>


         </div>
      </div>
   </section>

<script src="js/scriptabout.js"></script>

</body>
</html>