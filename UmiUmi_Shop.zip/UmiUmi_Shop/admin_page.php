<?php

@include 'db.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin page</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/components.css">
<style>
body {
   background-color:rgb(230,220,211) ;
}
.dashboard .box-container{
   display: grid;
   grid-template-columns: repeat(auto-fit, minmax(27rem, 1fr));
   gap:1.5rem;
   align-items: flex-start;
}

.dashboard .box-container .box{
   padding:1.5rem;
   text-align: center;
   border:6px groove white;
   background-color: rgb(215, 226, 236);
   border-radius: .5rem;
   transition:0.5s ease;
}
.dashboard .box-container .box:hover{
   border:3px double red;
}
.dashboard .box-container .box a.btn{
   display: block;
   width: 100%;
   margin-top: 1rem;
   border-radius: 10px;
   color:black;
   font-size: 2rem;
   padding:1.3rem 3rem;
   text-transform: capitalize;
   cursor: pointer;
   text-align: center;
   background-color:rgb(215, 233, 205);
   border:7px outset white;
   transition:0.5s ease;
}
.dashboard .box-container .box a.btn:hover{
   background-color:rgb(215, 233, 205);
   color:black;
   border:3px inset white;
}
.dashboard .box-container .box h3{
   font-size: 3.5rem;
   color:var(--black);
}

.dashboard .box-container .box p{
   font-size: 2rem;
   background-color: #acb5bf;
   color:var(--light-color);
   padding:1.5rem;
   margin:1rem 0;
   border:5px groove white;
   border-radius: .5rem;
   color:var(--black);
}
</style>


</head>
<body>
   
<?php include 'admin_header.php'; ?>

<section class="dashboard">

   <h1 class="title">Admin Dashboard</h1>

   <div class="box-container">

      <div class="box">
      <?php
         $total_pendings = 0;
         $select_pendings = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
         $select_pendings->execute(['pending']);
         while($fetch_pendings = $select_pendings->fetch(PDO::FETCH_ASSOC)){
            $total_pendings += $fetch_pendings['total_price'];
         };
      ?>
      <h3>MYR<?= $total_pendings; ?></h3>
      <p>total pendings</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
      <?php
         $total_completed = 0;
         $select_completed = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
         $select_completed->execute(['completed']);
         while($fetch_completed = $select_completed->fetch(PDO::FETCH_ASSOC)){
            $total_completed += $fetch_completed['total_price'];
         };
      ?>
      <h3>MYR<?= $total_completed; ?></h3>
      <p>completed orders</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
      <?php
         $select_orders = $conn->prepare("SELECT * FROM `orders`");
         $select_orders->execute();
         $number_of_orders = $select_orders->rowCount();
      ?>
      <h3><?= $number_of_orders; ?></h3>
      <p>orders placed</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
      <?php
         $select_products = $conn->prepare("SELECT * FROM `products`");
         $select_products->execute();
         $number_of_products = $select_products->rowCount();
      ?>
      <h3><?= $number_of_products; ?></h3>
      <p>products added</p>
      <a href="admin_products.php" class="btn">see products</a>
      </div>

   </div>

</section>

<script src="js/script.js"></script>

</body>
</html>